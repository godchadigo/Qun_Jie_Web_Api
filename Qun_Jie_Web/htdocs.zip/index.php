<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>主頁面</title>
</head>

<body>
    <input type="text" name="msg">

    <?php
        echo "您送出的訊息為：". $msg;
    ?>
</body>
</html>